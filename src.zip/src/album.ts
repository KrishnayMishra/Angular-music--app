export class Album{
    public id : number=0;
    public title: string="";
    public artist : string="";
    public genre : string="";
}